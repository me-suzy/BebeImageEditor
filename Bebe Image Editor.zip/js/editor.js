/**
 * Bebe Image Editor - Logică canvas, layere, instrumente (inspirat Fireworks)
 */
(function () {
    'use strict';

    const mainCanvas = document.getElementById('mainCanvas');
    const drawCanvas = document.getElementById('drawCanvas');
    const canvasWrap = document.getElementById('canvasWrap');
    const canvasInner = document.getElementById('canvasInner');
    const ctx = mainCanvas.getContext('2d');
    const drawCtx = drawCanvas.getContext('2d');

    let canvasWidth = 1161;
    let canvasHeight = 900;
    let canvasColor = '#ffffff';
    let layers = [];
    let nextLayerId = 1;
    let currentTool = 'pointer';
    let fillColor = '#000000';
    let strokeColor = '#ff0000';
    let globalOpacity = 1;
    let zoom = 1;
    let panX = 0, panY = 0;
    let selectedLayerId = null;
    let dragStart = null;
    let shapeStart = null;
    let brushStart = null;
    let resizeStart = null;
    let panStart = null;
    const HANDLE_SIZE = 8;
    const VECTOR_TYPES = ['rect', 'ellipse', 'line', 'text'];
    let docName = 'Untitled-1';
    let canvasAnchor = 'c';
    let brushSizePx = 4;
    var imageCache = {};
    const MAX_UNDO = 50;
    let undoStack = [];
    let redoStack = [];
    let nextDocId = 1;
    let documents = [];
    let currentDocIndex = 0;
    let pendingCloseIndex = null;
    let pickingCanvasColorMode = null;

    const canvasColorEl = document.getElementById('canvasColor');
    const fillColorEl = document.getElementById('fillColor');
    const strokeColorEl = document.getElementById('strokeColor');
    const globalOpacityEl = document.getElementById('globalOpacity');
    const opacityValEl = document.getElementById('opacityVal');
    const brushSizeEl = document.getElementById('brushSize');
    const brushSizeValEl = document.getElementById('brushSizeVal');
    const zoomInputEl = document.getElementById('zoomInput');
    const docInfoEl = document.getElementById('docInfo');
    const statusCoordsEl = document.getElementById('statusCoords');
    const statusSizeEl = document.getElementById('statusSize');
    const layersListEl = document.getElementById('layersList');
    const propDocNameEl = document.getElementById('propDocName');
    const propLayerOpacityEl = document.getElementById('propLayerOpacity');
    const propSelectionColorsEl = document.getElementById('propSelectionColors');
    const propLayerFillEl = document.getElementById('propLayerFill');
    const propLayerStrokeEl = document.getElementById('propLayerStroke');
    const layerOpacitySliderEl = document.getElementById('layerOpacitySlider');
    const layerOpacityValEl = document.getElementById('layerOpacityVal');

    function saveState() {
        return {
            layers: JSON.parse(JSON.stringify(layers)),
            nextLayerId: nextLayerId,
            canvasWidth: canvasWidth,
            canvasHeight: canvasHeight,
            canvasColor: canvasColor
        };
    }

    function restoreState(state) {
        layers = state.layers.map(l => ({ ...l }));
        nextLayerId = state.nextLayerId;
        canvasWidth = state.canvasWidth;
        canvasHeight = state.canvasHeight;
        canvasColor = state.canvasColor;
        canvasColorEl.value = canvasColor;
        imageCache = {};
        drawCtx.clearRect(0, 0, mainCanvas.width, mainCanvas.height);
        render();
    }

    function pushUndo() {
        undoStack.push(saveState());
        if (undoStack.length > MAX_UNDO) undoStack.shift();
        redoStack = [];
        updateUndoRedoButtons();
    }

    function undo() {
        if (undoStack.length === 0) return;
        redoStack.push(saveState());
        restoreState(undoStack.pop());
        updateUndoRedoButtons();
    }

    function redo() {
        if (redoStack.length === 0) return;
        undoStack.push(saveState());
        restoreState(redoStack.pop());
        updateUndoRedoButtons();
    }

    function updateUndoRedoButtons() {
        const btnUndo = document.getElementById('btnUndo');
        const btnRedo = document.getElementById('btnRedo');
        if (btnUndo) btnUndo.disabled = undoStack.length === 0;
        if (btnRedo) btnRedo.disabled = redoStack.length === 0;
    }

    function getDocState() {
        return {
            name: docName,
            layers: JSON.parse(JSON.stringify(layers)),
            nextLayerId: nextLayerId,
            canvasWidth: canvasWidth,
            canvasHeight: canvasHeight,
            canvasColor: canvasColor,
            undoStack: undoStack.map(s => ({ ...s, layers: s.layers.map(l => ({ ...l })) })),
            redoStack: redoStack.map(s => ({ ...s, layers: s.layers.map(l => ({ ...l })) }))
        };
    }

    function saveCurrentDocToStore() {
        if (documents.length === 0 || currentDocIndex < 0 || currentDocIndex >= documents.length) return;
        documents[currentDocIndex] = getDocState();
    }

    function loadDocFromStore(i) {
        if (i < 0 || i >= documents.length) return;
        const d = documents[i];
        docName = d.name;
        layers = d.layers.map(l => ({ ...l }));
        nextLayerId = d.nextLayerId;
        canvasWidth = d.canvasWidth;
        canvasHeight = d.canvasHeight;
        canvasColor = d.canvasColor;
        undoStack = d.undoStack.map(s => ({ ...s, layers: s.layers.map(l => ({ ...l })) }));
        redoStack = d.redoStack.map(s => ({ ...s, layers: s.layers.map(l => ({ ...l })) }));
        canvasColorEl.value = canvasColor;
        propDocNameEl.textContent = docName;
        imageCache = {};
        selectedLayerId = null;
        dragStart = null;
        shapeStart = null;
        brushStart = null;
        drawCtx.clearRect(0, 0, mainCanvas.width || canvasWidth, mainCanvas.height || canvasHeight);
        render();
        updateUndoRedoButtons();
    }

    function renderTabs() {
        const container = document.getElementById('docTabs');
        if (!container) return;
        container.innerHTML = '';
        documents.forEach((doc, i) => {
            const active = i === currentDocIndex ? ' active' : '';
            const tab = document.createElement('div');
            tab.className = 'doc-tab' + active;
            tab.dataset.index = String(i);
            const label = document.createElement('span');
            label.className = 'doc-tab-label';
            label.textContent = doc.name;
            label.title = doc.name;
            const closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.className = 'doc-tab-close';
            closeBtn.title = 'Închide';
            closeBtn.innerHTML = '×';
            closeBtn.addEventListener('click', (e) => { e.stopPropagation(); requestCloseTab(i); });
            tab.appendChild(label);
            tab.appendChild(closeBtn);
            tab.addEventListener('click', () => { if (i !== currentDocIndex) { saveCurrentDocToStore(); currentDocIndex = i; loadDocFromStore(i); renderTabs(); } });
            container.appendChild(tab);
        });
    }

    function requestCloseTab(i) {
        pendingCloseIndex = i;
        document.getElementById('closeConfirmDocName').textContent = documents[i].name;
        document.getElementById('closeConfirmOverlay').classList.add('visible');
    }

    function doCloseTab(saveFirst) {
        const i = pendingCloseIndex;
        if (i === null || i === undefined) return;
        pendingCloseIndex = null;
        document.getElementById('closeConfirmOverlay').classList.remove('visible');
        saveCurrentDocToStore();
        if (saveFirst) {
            loadDocFromStore(i);
            const link = document.createElement('a');
            link.download = (docName || 'image') + '.png';
            link.href = mainCanvas.toDataURL('image/png');
            link.click();
        }
        documents.splice(i, 1);
        if (documents.length === 0) {
            documents.push({
                name: 'Untitled-' + (nextDocId++),
                layers: [],
                nextLayerId: 1,
                canvasWidth: 1161,
                canvasHeight: 900,
                canvasColor: '#ffffff',
                undoStack: [],
                redoStack: []
            });
            currentDocIndex = 0;
        } else {
            if (i < currentDocIndex) currentDocIndex--;
            currentDocIndex = Math.min(currentDocIndex, documents.length - 1);
        }
        loadDocFromStore(currentDocIndex);
        renderTabs();
    }

    function getCanvasRect() {
        const r = mainCanvas.getBoundingClientRect();
        return { left: r.left, top: r.top, width: r.width, height: r.height };
    }

    function screenToCanvas(sx, sy) {
        const r = getCanvasRect();
        if (r.width <= 0 || r.height <= 0) return { x: 0, y: 0 };
        return {
            x: Math.floor((sx - r.left) * (canvasWidth / r.width)),
            y: Math.floor((sy - r.top) * (canvasHeight / r.height))
        };
    }

    function createLayer(opt) {
        const layer = {
            id: nextLayerId++,
            type: opt.type || 'rect',
            x: opt.x ?? 0,
            y: opt.y ?? 0,
            w: opt.w ?? 100,
            h: opt.h ?? 100,
            opacity: opt.opacity ?? 1,
            fill: opt.fill ?? fillColor,
            stroke: opt.stroke ?? strokeColor,
            text: opt.text ?? '',
            imageData: opt.imageData ?? null,
            visible: true
        };
        layers.push(layer);
        return layer;
    }

    function render() {
        mainCanvas.width = canvasWidth;
        mainCanvas.height = canvasHeight;
        mainCanvas.style.width = canvasWidth * zoom + 'px';
        mainCanvas.style.height = canvasHeight * zoom + 'px';
        drawCanvas.width = canvasWidth;
        drawCanvas.height = canvasHeight;
        drawCanvas.style.width = canvasWidth * zoom + 'px';
        drawCanvas.style.height = canvasHeight * zoom + 'px';

        ctx.fillStyle = canvasColor;
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);

        layers.forEach(layer => {
            if (!layer.visible) return;
            ctx.globalAlpha = layer.opacity * globalOpacity;
            if (layer.type === 'image' && layer.imageData) {
                var img = imageCache[layer.id];
                if (!img) {
                    img = new Image();
                    img._layerId = layer.id;
                    img.onload = function() { imageCache[this._layerId] = this; render(); };
                    img.src = layer.imageData;
                }
                if (img.complete && img.naturalWidth) ctx.drawImage(img, layer.x, layer.y, layer.w, layer.h);
            } else if (layer.type === 'rect') {
                ctx.fillStyle = layer.fill;
                ctx.fillRect(layer.x, layer.y, layer.w, layer.h);
                if (layer.stroke) {
                    ctx.strokeStyle = layer.stroke;
                    ctx.lineWidth = 2;
                    ctx.strokeRect(layer.x, layer.y, layer.w, layer.h);
                }
            } else if (layer.type === 'ellipse') {
                ctx.fillStyle = layer.fill;
                ctx.beginPath();
                const cx = layer.x + layer.w / 2, cy = layer.y + layer.h / 2;
                ctx.ellipse(cx, cy, layer.w / 2, layer.h / 2, 0, 0, Math.PI * 2);
                ctx.fill();
                if (layer.stroke) {
                    ctx.strokeStyle = layer.stroke;
                    ctx.lineWidth = 2;
                    ctx.stroke();
                }
            } else if (layer.type === 'text' && layer.text) {
                ctx.fillStyle = layer.fill;
                ctx.font = (layer.fontSize || 16) + 'px sans-serif';
                ctx.fillText(layer.text, layer.x, layer.y + (layer.fontSize || 16));
            } else if (layer.type === 'line') {
                ctx.strokeStyle = layer.stroke || strokeColor;
                ctx.lineWidth = layer.lineWidth || 2;
                ctx.beginPath();
                ctx.moveTo(layer.x, layer.y);
                ctx.lineTo(layer.x + layer.w, layer.y + layer.h);
                ctx.stroke();
            }
        });
        ctx.globalAlpha = 1;

        if (selectedLayerId) {
            const layer = layers.find(l => l.id === selectedLayerId);
            if (layer) {
                const b = getLayerBounds(layer, ctx);
                ctx.strokeStyle = '#0e639c';
                ctx.lineWidth = 2;
                ctx.setLineDash([4, 4]);
                ctx.strokeRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4);
                ctx.setLineDash([]);
                const half = HANDLE_SIZE / 2;
                ctx.fillStyle = '#fff';
                ctx.strokeStyle = '#0e639c';
                ctx.lineWidth = 1;
                getResizeHandles(layer, ctx).forEach(h => {
                    ctx.fillRect(h.cx - half, h.cy - half, HANDLE_SIZE, HANDLE_SIZE);
                    ctx.strokeRect(h.cx - half, h.cy - half, HANDLE_SIZE, HANDLE_SIZE);
                });
            }
        }

        statusSizeEl.textContent = canvasWidth + ' x ' + canvasHeight;
        docInfoEl.textContent = docName + ' @ ' + Math.round(zoom * 100) + '%';
        renderLayersList();
        var selLayer = layers.find(l => l.id === selectedLayerId);
        if (selLayer) {
            propLayerOpacityEl.style.display = 'flex';
            layerOpacitySliderEl.value = Math.round(selLayer.opacity * 100);
            layerOpacityValEl.textContent = Math.round(selLayer.opacity * 100) + '%';
            var isVector = VECTOR_TYPES.indexOf(selLayer.type) >= 0;
            if (propSelectionColorsEl) {
                propSelectionColorsEl.style.display = isVector ? 'block' : 'none';
                if (isVector && propLayerFillEl && propLayerStrokeEl) {
                    propLayerFillEl.value = selLayer.fill || fillColor;
                    propLayerStrokeEl.value = selLayer.stroke || strokeColor;
                }
            }
        } else {
            propLayerOpacityEl.style.display = 'none';
            if (propSelectionColorsEl) propSelectionColorsEl.style.display = 'none';
        }
    }

    function renderLayersList() {
        layersListEl.innerHTML = '';
        [...layers].reverse().forEach(layer => {
            const li = document.createElement('li');
            li.className = selectedLayerId === layer.id ? 'active' : '';
            li.innerHTML = '<span>' + (layer.type + ' ' + layer.id) + '</span><span class="layer-opacity">' + Math.round(layer.opacity * 100) + '%</span>';
            li.onclick = () => { selectedLayerId = layer.id; render(); };
            layersListEl.appendChild(li);
        });
    }

    function getLayerAtWithCtx(x, y, measureCtx) {
        for (let i = layers.length - 1; i >= 0; i--) {
            const L = layers[i];
            if (!L.visible) continue;
            if (L.type === 'image' || L.type === 'rect' || L.type === 'ellipse') {
                if (x >= L.x && x <= L.x + L.w && y >= L.y && y <= L.y + L.h) return L;
            } else if (L.type === 'text') {
                measureCtx.font = (L.fontSize || 16) + 'px sans-serif';
                const tw = measureCtx.measureText(L.text).width;
                if (x >= L.x && x <= L.x + tw && y >= L.y - (L.fontSize || 16) && y <= L.y + 4) return L;
            } else if (L.type === 'line') {
                const dx = L.w, dy = L.h;
                const len = Math.sqrt(dx * dx + dy * dy) || 1;
                const nx = -dy / len, ny = dx / len;
                const px = x - L.x, py = y - L.y;
                const dist = Math.abs(px * nx + py * ny);
                const t = (px * dx + py * dy) / (len * len);
                if (t >= 0 && t <= 1 && dist <= 6) return L;
            }
        }
        return null;
    }

    function getLayerBounds(layer, measureCtx) {
        if (layer.type === 'line') {
            const left = Math.min(layer.x, layer.x + layer.w);
            const top = Math.min(layer.y, layer.y + layer.h);
            return { x: left, y: top, w: Math.abs(layer.w), h: Math.abs(layer.h) };
        }
        if (layer.type === 'text') {
            const fs = layer.fontSize || 16;
            const tw = measureCtx.measureText(layer.text || '').width;
            return { x: layer.x, y: layer.y - fs, w: Math.max(1, tw), h: fs };
        }
        return { x: layer.x, y: layer.y, w: layer.w, h: layer.h };
    }

    function getResizeHandles(layer, measureCtx) {
        const b = getLayerBounds(layer, measureCtx);
        const x = b.x, y = b.y, w = b.w, h = b.h;
        const hw = Math.max(0, w / 2), hh = Math.max(0, h / 2);
        return [
            { handle: 'nw', cx: x, cy: y },
            { handle: 'n', cx: x + hw, cy: y },
            { handle: 'ne', cx: x + w, cy: y },
            { handle: 'e', cx: x + w, cy: y + hh },
            { handle: 'se', cx: x + w, cy: y + h },
            { handle: 's', cx: x + hw, cy: y + h },
            { handle: 'sw', cx: x, cy: y + h },
            { handle: 'w', cx: x, cy: y + hh }
        ];
    }

    function getHandleAt(px, py) {
        if (!selectedLayerId) return null;
        const layer = layers.find(l => l.id === selectedLayerId);
        if (!layer) return null;
        const half = HANDLE_SIZE / 2;
        const handles = getResizeHandles(layer, ctx);
        for (let i = 0; i < handles.length; i++) {
            const h = handles[i];
            if (px >= h.cx - half && px <= h.cx + half && py >= h.cy - half && py <= h.cy + half)
                return { layer, handle: h.handle };
        }
        return null;
    }

    function applyResizeToLayer(layer, newX, newY, newW, newH) {
        const minSize = 1;
        newW = Math.max(minSize, newW);
        newH = Math.max(minSize, newH);
        if (layer.type === 'line') {
            layer.x = newX;
            layer.y = newY;
            layer.w = newW;
            layer.h = newH;
            return;
        }
        if (layer.type === 'text') {
            layer.x = newX;
            layer.y = newY + newH;
            layer.fontSize = Math.max(8, Math.round(newH));
            return;
        }
        layer.x = newX;
        layer.y = newY;
        layer.w = newW;
        layer.h = newH;
    }

    function redraw() {
        const sel = selectedLayerId;
        render();
        selectedLayerId = sel;
    }

    // ---- Tools ----
    document.querySelectorAll('.tool-btn[data-tool]').forEach(btn => {
        btn.addEventListener('click', () => setTool(btn.dataset.tool));
    });

    document.getElementById('swapColors').addEventListener('click', () => {
        const t = fillColorEl.value;
        fillColorEl.value = strokeColorEl.value;
        strokeColorEl.value = t;
        fillColor = fillColorEl.value;
        strokeColor = strokeColorEl.value;
    });

    fillColorEl.addEventListener('input', () => { fillColor = fillColorEl.value; });
    strokeColorEl.addEventListener('input', () => { strokeColor = strokeColorEl.value; });
    canvasColorEl.addEventListener('input', () => { pushUndo(); canvasColor = canvasColorEl.value; render(); });
    if (brushSizeEl) {
        brushSizeEl.addEventListener('input', () => {
            brushSizePx = Math.max(1, Math.min(50, parseInt(brushSizeEl.value, 10) || 4));
            brushSizeEl.value = brushSizePx;
            if (brushSizeValEl) brushSizeValEl.textContent = brushSizePx;
        });
        if (brushSizeValEl) brushSizeValEl.textContent = brushSizePx;
    }
    document.querySelectorAll('.palette-swatch').forEach(btn => {
        btn.style.backgroundColor = btn.dataset.color;
        btn.addEventListener('click', (e) => {
            const c = btn.dataset.color;
            if (e.shiftKey) {
                strokeColor = c;
                strokeColorEl.value = c;
            } else {
                fillColor = c;
                fillColorEl.value = c;
            }
            render();
        });
    });
    globalOpacityEl.addEventListener('input', () => {
        globalOpacity = globalOpacityEl.value / 100;
        opacityValEl.textContent = globalOpacityEl.value + '%';
        render();
    });
    zoomInputEl.addEventListener('change', () => {
        zoom = Math.max(0.1, Math.min(4, zoomInputEl.value / 100));
        zoomInputEl.value = Math.round(zoom * 100);
        render();
    });

    function getPixelColorAt(cx, cy) {
        const imgData = ctx.getImageData(Math.max(0, Math.floor(cx)), Math.max(0, Math.floor(cy)), 1, 1);
        const r = imgData.data[0], g = imgData.data[1], b = imgData.data[2];
        return '#' + [r, g, b].map(x => ('0' + x.toString(16)).slice(-2)).join('');
    }

    // ---- Mouse on canvas ----
    function handleCanvasMouseDown(e) {
        const rect = getCanvasRect();
        const p = screenToCanvas(e.clientX, e.clientY);
        if (p.x < 0 || p.y < 0 || p.x > canvasWidth || p.y > canvasHeight) return;

        if (pickingCanvasColorMode) {
            const hex = getPixelColorAt(p.x, p.y);
            if (pickingCanvasColorMode === 'dialog') {
                const canvasSizeBgColor = document.getElementById('canvasSizeBgColor');
                const hint = document.getElementById('canvasSizePickHint');
                if (canvasSizeBgColor) canvasSizeBgColor.value = hex;
                if (hint) hint.style.display = 'none';
                document.getElementById('canvasSizeOverlay').classList.add('visible');
            } else if (pickingCanvasColorMode === 'selection') {
                var layer = layers.find(l => l.id === selectedLayerId);
                if (layer && VECTOR_TYPES.indexOf(layer.type) >= 0) {
                    pushUndo();
                    layer.fill = hex;
                    if (propLayerFillEl) propLayerFillEl.value = hex;
                    fillColor = hex;
                    if (fillColorEl) fillColorEl.value = hex;
                    render();
                }
            } else {
                pushUndo();
                canvasColor = hex;
                canvasColorEl.value = hex;
                render();
            }
            pickingCanvasColorMode = null;
            statusCoordsEl.textContent = 'x: ' + p.x + ', y: ' + p.y;
            return;
        }

        if (currentTool === 'pointer') {
            const handleHit = getHandleAt(p.x, p.y);
            if (handleHit) {
                pushUndo();
                const b = getLayerBounds(handleHit.layer, ctx);
                resizeStart = {
                    layer: handleHit.layer,
                    handle: handleHit.handle,
                    startX: p.x,
                    startY: p.y,
                    startBounds: { x: b.x, y: b.y, w: b.w, h: b.h }
                };
            } else {
                const layer = getLayerAtWithCtx(p.x, p.y, ctx);
                selectedLayerId = layer ? layer.id : null;
                const isVector = layer && VECTOR_TYPES.indexOf(layer.type) >= 0;
                if (layer && isVector) pushUndo();
                dragStart = isVector && layer ? { layer, startX: p.x - layer.x, startY: p.y - layer.y } : null;
            }
        } else if (currentTool === 'hand') {
            panStart = { startX: e.clientX, startY: e.clientY, startPanX: panX, startPanY: panY };
        } else if (currentTool === 'rect' || currentTool === 'ellipse' || currentTool === 'line') {
            shapeStart = { x: p.x, y: p.y };
        } else if (currentTool === 'text') {
            const text = window.prompt('Text:', '');
            if (text) {
                pushUndo();
                createLayer({ type: 'text', x: p.x, y: p.y, w: 0, h: 0, text, fill: fillColor, fontSize: 16 });
                render();
            }
        } else if (currentTool === 'eyedropper') {
            const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
            const i = (Math.floor(p.y) * canvasWidth + Math.floor(p.x)) * 4;
            const r = imgData.data[i], g = imgData.data[i + 1], b = imgData.data[i + 2];
            const hex = '#' + [r, g, b].map(x => ('0' + x.toString(16)).slice(-2)).join('');
            fillColorEl.value = hex;
            fillColor = hex;
            var layer = layers.find(l => l.id === selectedLayerId);
            if (layer && VECTOR_TYPES.indexOf(layer.type) >= 0) {
                pushUndo();
                layer.fill = hex;
                if (propLayerFillEl) propLayerFillEl.value = hex;
                render();
            }
        } else if (currentTool === 'brush' || currentTool === 'pencil' || currentTool === 'eraser') {
            fillColor = fillColorEl.value;
            strokeColor = strokeColorEl.value;
            brushStart = { x: p.x, y: p.y };
        } else if (currentTool === 'paintbucket') {
            pushUndo();
            const imgData = ctx.getImageData(0, 0, canvasWidth, canvasHeight);
            const target = (Math.floor(p.y) * canvasWidth + Math.floor(p.x)) * 4;
            const r = imgData.data[target], g = imgData.data[target + 1], b = imgData.data[target + 2];
            const fillR = parseInt(fillColor.slice(1, 3), 16), fillG = parseInt(fillColor.slice(3, 5), 16), fillB = parseInt(fillColor.slice(5, 7), 16);
            const stack = [[Math.floor(p.x), Math.floor(p.y)]];
            const seen = new Set([p.y * canvasWidth + p.x]);
            const tol = 30;
            while (stack.length) {
                const [cx, cy] = stack.pop();
                const i = (cy * canvasWidth + cx) * 4;
                imgData.data[i] = fillR;
                imgData.data[i + 1] = fillG;
                imgData.data[i + 2] = fillB;
                [[cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]].forEach(([nx, ny]) => {
                    if (nx < 0 || nx >= canvasWidth || ny < 0 || ny >= canvasHeight) return;
                    const key = ny * canvasWidth + nx;
                    if (seen.has(key)) return;
                    const j = key * 4;
                    if (Math.abs(imgData.data[j] - r) <= tol && Math.abs(imgData.data[j + 1] - g) <= tol && Math.abs(imgData.data[j + 2] - b) <= tol) {
                        seen.add(key);
                        stack.push([nx, ny]);
                    }
                });
            }
            ctx.putImageData(imgData, 0, 0);
            var flatUrl = mainCanvas.toDataURL('image/png');
            layers = [];
            nextLayerId = 1;
            createLayer({ type: 'image', x: 0, y: 0, w: canvasWidth, h: canvasHeight, imageData: flatUrl });
            selectedLayerId = null;
            render();
        }
        render();
    }

    function getResizeCursor(handle) {
        const cursors = { nw: 'nwse-resize', n: 'n-resize', ne: 'nesw-resize', e: 'e-resize', se: 'nwse-resize', s: 's-resize', sw: 'nesw-resize', w: 'w-resize' };
        return cursors[handle] || 'default';
    }

    function handleCanvasMouseMove(e) {
        const p = screenToCanvas(e.clientX, e.clientY);
        statusCoordsEl.textContent = 'x: ' + p.x + ', y: ' + p.y;

        if (panStart) {
            panX = panStart.startPanX + (e.clientX - panStart.startX);
            panY = panStart.startPanY + (e.clientY - panStart.startY);
            if (canvasInner) canvasInner.style.transform = 'translate(' + panX + 'px,' + panY + 'px)';
            canvasWrap.style.cursor = 'grabbing';
        } else if (resizeStart) {
            canvasWrap.style.cursor = getResizeCursor(resizeStart.handle);
            const rs = resizeStart;
            const dx = p.x - rs.startX, dy = p.y - rs.startY;
            let left = rs.startBounds.x, top = rs.startBounds.y, right = rs.startBounds.x + rs.startBounds.w, bottom = rs.startBounds.y + rs.startBounds.h;
            const minSize = 1;
            switch (rs.handle) {
                case 'nw': left += dx; top += dy; break;
                case 'n': top += dy; break;
                case 'ne': top += dy; right += dx; break;
                case 'e': right += dx; break;
                case 'se': right += dx; bottom += dy; break;
                case 's': bottom += dy; break;
                case 'sw': left += dx; bottom += dy; break;
                case 'w': left += dx; break;
            }
            let w = right - left, h = bottom - top;
            if (w < minSize) { w = minSize; if (rs.handle === 'w' || rs.handle === 'nw' || rs.handle === 'sw') left = right - minSize; else right = left + minSize; }
            if (h < minSize) { h = minSize; if (rs.handle === 'n' || rs.handle === 'nw' || rs.handle === 'ne') top = bottom - minSize; else bottom = top + minSize; }
            applyResizeToLayer(rs.layer, left, top, w, h);
            render();
        } else {
            if (dragStart) {
                canvasWrap.style.cursor = 'move';
                dragStart.layer.x = p.x - dragStart.startX;
                dragStart.layer.y = p.y - dragStart.startY;
                render();
            } else if (currentTool === 'pointer') {
                const handleHit = getHandleAt(p.x, p.y);
                canvasWrap.style.cursor = handleHit ? getResizeCursor(handleHit.handle) : 'default';
            } else if (currentTool === 'hand') {
                canvasWrap.style.cursor = 'grab';
            } else {
                canvasWrap.style.cursor = 'default';
            }
        }
        if (!resizeStart && brushStart && (currentTool === 'brush' || currentTool === 'pencil' || currentTool === 'eraser')) {
            drawCtx.strokeStyle = currentTool === 'eraser' ? canvasColor : (fillColor = fillColorEl.value);
            drawCtx.lineWidth = currentTool === 'eraser' ? Math.max(4, brushSizePx * 2) : brushSizePx;
            drawCtx.lineCap = 'round';
            drawCtx.globalAlpha = globalOpacity;
            drawCtx.beginPath();
            drawCtx.moveTo(brushStart.x, brushStart.y);
            drawCtx.lineTo(p.x, p.y);
            drawCtx.stroke();
            drawCtx.globalAlpha = 1;
            brushStart = { x: p.x, y: p.y };
        } else if (shapeStart && (currentTool === 'rect' || currentTool === 'ellipse' || currentTool === 'line')) {
            drawCtx.clearRect(0, 0, canvasWidth, canvasHeight);
            drawCtx.strokeStyle = strokeColor;
            drawCtx.fillStyle = fillColor;
            drawCtx.globalAlpha = globalOpacity;
            const x = Math.min(shapeStart.x, p.x), y = Math.min(shapeStart.y, p.y);
            const w = Math.abs(p.x - shapeStart.x), h = Math.abs(p.y - shapeStart.y);
            if (currentTool === 'rect') {
                drawCtx.fillRect(x, y, w, h);
                drawCtx.strokeRect(x, y, w, h);
            } else if (currentTool === 'ellipse') {
                drawCtx.beginPath();
                drawCtx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
                drawCtx.fill();
                drawCtx.stroke();
            } else if (currentTool === 'line') {
                drawCtx.beginPath();
                drawCtx.moveTo(shapeStart.x, shapeStart.y);
                drawCtx.lineTo(p.x, p.y);
                drawCtx.stroke();
            }
            drawCtx.globalAlpha = 1;
        }
    }

    function setTool(tool) {
        currentTool = tool;
        document.querySelectorAll('.tool-btn').forEach(b => b.classList.remove('active'));
        const btn = document.querySelector('.tool-btn[data-tool="' + tool + '"]');
        if (btn) btn.classList.add('active');
        canvasWrap.classList.toggle('has-draw', ['rect', 'ellipse', 'brush', 'pencil', 'eraser', 'line'].indexOf(currentTool) >= 0);
        drawCanvas.style.pointerEvents = ['rect', 'ellipse', 'brush', 'pencil', 'eraser', 'line'].indexOf(currentTool) >= 0 ? 'auto' : 'none';
        canvasWrap.style.cursor = (tool === 'hand') ? 'grab' : 'default';
    }

    function handleCanvasMouseUp(e) {
        if (shapeStart && (currentTool === 'rect' || currentTool === 'ellipse' || currentTool === 'line')) {
            const p = screenToCanvas(e.clientX, e.clientY);
            const x = Math.min(shapeStart.x, p.x), y = Math.min(shapeStart.y, p.y);
            const w = Math.max(1, Math.abs(p.x - shapeStart.x)), h = Math.max(1, Math.abs(p.y - shapeStart.y));
            pushUndo();
            let newLayer = null;
            if (currentTool === 'rect') newLayer = createLayer({ type: 'rect', x, y, w, h, fill: fillColor, stroke: strokeColor });
            else if (currentTool === 'ellipse') newLayer = createLayer({ type: 'ellipse', x, y, w, h, fill: fillColor, stroke: strokeColor });
            else if (currentTool === 'line') {
                newLayer = createLayer({ type: 'line', x: shapeStart.x, y: shapeStart.y, w: p.x - shapeStart.x, h: p.y - shapeStart.y });
            }
            shapeStart = null;
            drawCtx.clearRect(0, 0, canvasWidth, canvasHeight);
            if (newLayer) {
                selectedLayerId = newLayer.id;
                setTool('pointer');
            }
            render();
        }
        resizeStart = null;
        dragStart = null;
        panStart = null;
        if (brushStart && (currentTool === 'brush' || currentTool === 'pencil' || currentTool === 'eraser')) {
            pushUndo();
            var w = canvasWidth, h = canvasHeight;
            createLayer({ type: 'image', x: 0, y: 0, w: w, h: h, imageData: drawCanvas.toDataURL('image/png') });
            drawCtx.clearRect(0, 0, w, h);
            brushStart = null;
            render();
        }
    }

    canvasWrap.addEventListener('mousedown', handleCanvasMouseDown);
    canvasWrap.addEventListener('mousemove', handleCanvasMouseMove);
    canvasWrap.addEventListener('mouseup', handleCanvasMouseUp);
    canvasWrap.addEventListener('mouseleave', () => { shapeStart = null; dragStart = null; resizeStart = null; panStart = null; brushStart = null; drawCtx.clearRect(0, 0, canvasWidth, canvasHeight); });

    // ---- Canvas Size ----
    const canvasSizeOverlay = document.getElementById('canvasSizeOverlay');
    const canvasNewW = document.getElementById('canvasNewW');
    const canvasNewH = document.getElementById('canvasNewH');
    const anchorGrid = document.getElementById('anchorGrid');
    const canvasCurrentSize = document.getElementById('canvasCurrentSize');

    document.getElementById('btnCanvasSize').addEventListener('click', () => {
        canvasNewW.value = canvasWidth;
        canvasNewH.value = canvasHeight;
        canvasCurrentSize.textContent = canvasWidth + ' x ' + canvasHeight + ' pixels';
        document.getElementById('canvasSizeBgColor').value = canvasColor;
        document.getElementById('canvasSizePickHint').style.display = 'none';
        pickingCanvasColorMode = null;
        anchorGrid.querySelectorAll('button').forEach(b => b.classList.remove('active'));
        anchorGrid.querySelector('[data-anchor="' + canvasAnchor + '"]').classList.add('active');
        canvasSizeOverlay.classList.add('visible');
    });
    document.getElementById('canvasSizeEyedropper').addEventListener('click', () => {
        canvasSizeOverlay.classList.remove('visible');
        pickingCanvasColorMode = 'dialog';
        document.getElementById('canvasSizePickHint').style.display = 'inline';
        statusCoordsEl.textContent = 'Click pe canvas pentru a alege culoarea fundalului';
    });
    document.getElementById('canvasColorEyedropper').addEventListener('click', () => {
        var layer = layers.find(l => l.id === selectedLayerId);
        if (layer && VECTOR_TYPES.indexOf(layer.type) >= 0) {
            pickingCanvasColorMode = 'selection';
            statusCoordsEl.textContent = 'Click pe imagine → culoarea se aplică la OBIECTUL selectat';
        } else {
            pickingCanvasColorMode = 'properties';
            statusCoordsEl.textContent = 'Click pe imagine → culoarea se aplică la FUNDALUL paginii';
        }
    });
    var propEyedropperFillEl = document.getElementById('propEyedropperFill');
    if (propEyedropperFillEl) {
        propEyedropperFillEl.addEventListener('click', () => {
            if (!selectedLayerId) return;
            var layer = layers.find(l => l.id === selectedLayerId);
            if (layer && VECTOR_TYPES.indexOf(layer.type) >= 0) {
                pickingCanvasColorMode = 'selection';
                statusCoordsEl.textContent = 'Click pe imagine → culoarea se aplică la OBIECTUL selectat';
            }
        });
    }
    anchorGrid.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-anchor]');
        if (!btn) return;
        anchorGrid.querySelectorAll('button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        canvasAnchor = btn.dataset.anchor;
    });
    document.getElementById('canvasSizeOk').addEventListener('click', () => {
        pushUndo();
        canvasColor = document.getElementById('canvasSizeBgColor').value;
        canvasColorEl.value = canvasColor;
        const newW = Math.max(1, parseInt(canvasNewW.value, 10));
        const newH = Math.max(1, parseInt(canvasNewH.value, 10));
        const dx = newW - canvasWidth, dy = newH - canvasHeight;
        const [ax, ay] = { nw: [0, 0], n: [0.5, 0], ne: [1, 0], w: [0, 0.5], c: [0.5, 0.5], e: [1, 0.5], sw: [0, 1], s: [0.5, 1], se: [1, 1] }[canvasAnchor];
        layers.forEach(layer => {
            layer.x += dx * (1 - ax);
            layer.y += dy * (1 - ay);
        });
        canvasWidth = newW;
        canvasHeight = newH;
        document.getElementById('canvasSizePickHint').style.display = 'none';
        pickingCanvasColorMode = null;
        canvasSizeOverlay.classList.remove('visible');
        render();
    });
    document.getElementById('canvasSizeCancel').addEventListener('click', () => {
        document.getElementById('canvasSizePickHint').style.display = 'none';
        pickingCanvasColorMode = null;
        canvasSizeOverlay.classList.remove('visible');
    });

    // ---- Image Size ----
    const imageSizeOverlay = document.getElementById('imageSizeOverlay');
    const imageNewW = document.getElementById('imageNewW');
    const imageNewH = document.getElementById('imageNewH');
    const constrainProportions = document.getElementById('constrainProportions');

    document.getElementById('btnImageSize').addEventListener('click', () => {
        imageNewW.value = canvasWidth;
        imageNewH.value = canvasHeight;
        imageSizeOverlay.classList.add('visible');
    });
    imageNewW.addEventListener('input', () => {
        if (constrainProportions.checked && canvasWidth) imageNewH.value = Math.round(canvasHeight * imageNewW.value / canvasWidth);
    });
    imageNewH.addEventListener('input', () => {
        if (constrainProportions.checked && canvasHeight) imageNewW.value = Math.round(canvasWidth * imageNewH.value / canvasHeight);
    });
    document.getElementById('imageSizeOk').addEventListener('click', () => {
        pushUndo();
        const newW = Math.max(1, parseInt(imageNewW.value, 10));
        const newH = Math.max(1, parseInt(imageNewH.value, 10));
        const scaleX = newW / canvasWidth, scaleY = newH / canvasHeight;
        layers.forEach(layer => {
            layer.x *= scaleX;
            layer.y *= scaleY;
            layer.w *= scaleX;
            layer.h *= scaleY;
            if (layer.fontSize) layer.fontSize = Math.round(layer.fontSize * Math.min(scaleX, scaleY));
        });
        canvasWidth = newW;
        canvasHeight = newH;
        imageSizeOverlay.classList.remove('visible');
        render();
    });
    document.getElementById('imageSizeCancel').addEventListener('click', () => imageSizeOverlay.classList.remove('visible'));

    document.getElementById('btnFitCanvas').addEventListener('click', () => {
        pushUndo();
        let minX = 0, minY = 0, maxX = canvasWidth, maxY = canvasHeight;
        layers.forEach(l => {
            minX = Math.min(minX, l.x);
            minY = Math.min(minY, l.y);
            maxX = Math.max(maxX, l.x + l.w);
            maxY = Math.max(maxY, l.y + l.h);
        });
        const pad = 20;
        const newW = Math.max(100, maxX - minX + pad * 2);
        const newH = Math.max(100, maxY - minY + pad * 2);
        layers.forEach(l => { l.x -= minX - pad; l.y -= minY - pad; });
        canvasWidth = newW;
        canvasHeight = newH;
        render();
    });

    layerOpacitySliderEl.addEventListener('mousedown', () => {
        var layer = layers.find(l => l.id === selectedLayerId);
        if (layer) pushUndo();
    });
    layerOpacitySliderEl.addEventListener('input', () => {
        var layer = layers.find(l => l.id === selectedLayerId);
        if (layer) {
            layer.opacity = layerOpacitySliderEl.value / 100;
            layerOpacityValEl.textContent = layerOpacitySliderEl.value + '%';
            render();
        }
    });

    if (propLayerFillEl) {
        propLayerFillEl.addEventListener('input', () => {
            var layer = layers.find(l => l.id === selectedLayerId);
            if (layer && VECTOR_TYPES.indexOf(layer.type) >= 0) {
                pushUndo();
                layer.fill = propLayerFillEl.value;
                render();
            }
        });
    }
    if (propLayerStrokeEl) {
        propLayerStrokeEl.addEventListener('input', () => {
            var layer = layers.find(l => l.id === selectedLayerId);
            if (layer && VECTOR_TYPES.indexOf(layer.type) >= 0) {
                pushUndo();
                layer.stroke = propLayerStrokeEl.value;
                render();
            }
        });
    }

    // ---- Layers ----
    document.getElementById('btnAddLayer').addEventListener('click', () => {
        pushUndo();
        createLayer({ type: 'rect', x: 50, y: 50, w: 100, h: 100, fill: fillColor, stroke: strokeColor });
        render();
    });

    // ---- Close confirm dialog ----
    document.getElementById('closeConfirmSave').addEventListener('click', () => doCloseTab(true));
    document.getElementById('closeConfirmDontSave').addEventListener('click', () => doCloseTab(false));
    document.getElementById('closeConfirmCancel').addEventListener('click', () => {
        pendingCloseIndex = null;
        document.getElementById('closeConfirmOverlay').classList.remove('visible');
    });

    // ---- New / Open / Save ----
    document.getElementById('btnNew').addEventListener('click', () => {
        saveCurrentDocToStore();
        documents.push({
            name: 'Untitled-' + (nextDocId++),
            layers: [],
            nextLayerId: 1,
            canvasWidth: 1161,
            canvasHeight: 900,
            canvasColor: '#ffffff',
            undoStack: [],
            redoStack: []
        });
        currentDocIndex = documents.length - 1;
        loadDocFromStore(currentDocIndex);
        renderTabs();
    });

    const fileInput = document.getElementById('fileInput');
    document.getElementById('btnOpen').addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function () {
            const img = new Image();
            img.onload = function () {
                saveCurrentDocToStore();
                const c = document.createElement('canvas');
                c.width = img.width;
                c.height = img.height;
                c.getContext('2d').drawImage(img, 0, 0);
                const dataUrl = c.toDataURL('image/png');
                const newDoc = {
                    name: file.name.replace(/\.[^.]*$/, ''),
                    layers: [{
                        id: 1,
                        type: 'image',
                        x: 0,
                        y: 0,
                        w: img.width,
                        h: img.height,
                        opacity: 1,
                        fill: fillColor,
                        stroke: strokeColor,
                        text: '',
                        imageData: dataUrl,
                        visible: true
                    }],
                    nextLayerId: 2,
                    canvasWidth: img.width,
                    canvasHeight: img.height,
                    canvasColor: '#ffffff',
                    undoStack: [],
                    redoStack: []
                };
                documents.push(newDoc);
                currentDocIndex = documents.length - 1;
                loadDocFromStore(currentDocIndex);
                propDocNameEl.textContent = docName;
                renderTabs();
            };
            img.src = reader.result;
        };
        reader.readAsDataURL(file);
        fileInput.value = '';
    });

    document.getElementById('btnSave').addEventListener('click', () => {
        mainCanvas.width = canvasWidth;
        mainCanvas.height = canvasHeight;
        ctx.fillStyle = canvasColor;
        ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        layers.forEach(layer => {
            if (!layer.visible) return;
            ctx.globalAlpha = layer.opacity * globalOpacity;
            if (layer.type === 'image' && layer.imageData) {
                const img = new Image();
                img.src = layer.imageData;
                ctx.drawImage(img, layer.x, layer.y, layer.w, layer.h);
            } else if (layer.type === 'rect') {
                ctx.fillStyle = layer.fill;
                ctx.fillRect(layer.x, layer.y, layer.w, layer.h);
                if (layer.stroke) { ctx.strokeStyle = layer.stroke; ctx.lineWidth = 2; ctx.strokeRect(layer.x, layer.y, layer.w, layer.h); }
            } else if (layer.type === 'ellipse') {
                ctx.fillStyle = layer.fill;
                ctx.beginPath();
                ctx.ellipse(layer.x + layer.w / 2, layer.y + layer.h / 2, layer.w / 2, layer.h / 2, 0, 0, Math.PI * 2);
                ctx.fill();
                if (layer.stroke) { ctx.strokeStyle = layer.stroke; ctx.lineWidth = 2; ctx.stroke(); }
            } else if (layer.type === 'text' && layer.text) {
                ctx.fillStyle = layer.fill;
                ctx.font = (layer.fontSize || 16) + 'px sans-serif';
                ctx.fillText(layer.text, layer.x, layer.y + (layer.fontSize || 16));
            } else if (layer.type === 'line') {
                ctx.strokeStyle = layer.stroke || strokeColor;
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(layer.x, layer.y);
                ctx.lineTo(layer.x + layer.w, layer.y + layer.h);
                ctx.stroke();
            }
        });
        ctx.globalAlpha = 1;
        const link = document.createElement('a');
        link.download = (docName || 'image') + '.png';
        link.href = mainCanvas.toDataURL('image/png');
        link.click();
        render();
    });

    // ---- Undo / Redo buttons and keyboard ----
    document.getElementById('btnUndo').addEventListener('click', undo);
    document.getElementById('btnRedo').addEventListener('click', redo);
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'z') {
            e.preventDefault();
            if (e.shiftKey) redo();
            else undo();
        } else if (e.ctrlKey && e.key === 'y') {
            e.preventDefault();
            redo();
        } else if ((e.key === 'Delete' || e.key === 'Backspace') && selectedLayerId) {
            const active = document.activeElement;
            if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable)) return;
            e.preventDefault();
            pushUndo();
            layers = layers.filter(l => l.id !== selectedLayerId);
            selectedLayerId = null;
            render();
            updateUndoRedoButtons();
        }
    });

    // Init
    updateUndoRedoButtons();
    render();
    if (documents.length === 0) {
        documents = [getDocState()];
        currentDocIndex = 0;
        renderTabs();
    }
})();
